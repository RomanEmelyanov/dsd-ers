#ifndef PA_DEVS_H
#define PA_DEVS_H

void printPortAudioDevices();

#endif
