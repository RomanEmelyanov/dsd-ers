pactl load-module module-null-sink sink_name=virtual_sink  sink_properties=device.description=Virtual_Sink
pactl load-module module-null-sink sink_name=virtual_sink2  sink_properties=device.description=Virtual_Sink2


